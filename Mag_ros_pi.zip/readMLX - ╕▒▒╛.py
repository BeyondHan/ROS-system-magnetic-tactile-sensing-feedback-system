import smbus
import threading
import time
import csv
import os  # New import to check existing files
from concurrent.futures import ThreadPoolExecutor
import matplotlib.pyplot as plt

# Initialize I2C (SMBus)
bus = smbus.SMBus(1)

# MLX90393 I2C addresses
sensor_addresses = [0x0C, 0x0D, 0x0E, 0x0F]
sensor_labels = {addr: f"S{i+1}" for i, addr in enumerate(sensor_addresses)}

publish_rate = 100  # Sensor reading rate for the system (in Hz)
retries = 5
delay = 0.008  # Shouldn't go below 0.0075

# Data storage for plotting and CSV export
sensor_data = {addr: {'time': [], 'x': [], 'y': [], 'z': []} for addr in sensor_addresses}

# Function to determine the next available file name
def get_next_filename():
    """Function to find the next available file name with an increasing number suffix"""
    base_name = "sensor_data"
    i = 1
    while os.path.exists(f"{base_name}_{i}.csv"):
        i += 1
    return f"{base_name}_{i}.csv"

# Function to ask user for file name
def ask_for_filename():
    """Ask the user for a file name, or generate a numbered file name if '0' is entered"""
    user_input = input("Enter a name for the CSV file (enter '0' for auto-naming): ")
    if user_input == '0':
        return get_next_filename()
    else:
        return f"{user_input}.csv"

# CSV filename
csv_filename = ask_for_filename()

def init_mlx90393(address):
    """Function for initializing the MLX90393 sensor at the given I2C address"""
    for attempt in range(retries):
        try:
            config_register_0 = [0x00, 0x7C, 0x00]  # Configure sensor
            bus.write_i2c_block_data(address, 0x60, config_register_0)
            status = bus.read_byte(address)

            config_register_2 = [0x02, 0xB4, 0x08]  # Configure sensor
            bus.write_i2c_block_data(address, 0x60, config_register_2)
            status = bus.read_byte(address)
            return
        except Exception as e:
            print(f"Retry {attempt + 1}/{retries} failed for initializing sensor at address {address}: {e}")
            if attempt == retries - 1:
                print(f"Failed to initialize sensor at address {address} after {retries} retries: {e}")
                raise

def start_single_measurement(address):
    """Function to start a single measurement on the MLX90393"""
    for attempt in range(retries):
        try:
            bus.write_byte(address, 0x3E)  # Command to start single measurement
            bus.read_byte(address)
            time.sleep(delay)
            return
        except Exception as e:
            print(f"Retry {attempt + 1}/{retries} failed for starting measurement at address {address}: {e}")
            if attempt == retries - 1:
                print(f"Failed to start measurement for sensor at address {address} after {retries} retries: {e}")
                raise

def read_magnetic_field(address):
    """Function for reading magnetic flux data from the MLX90393 sensor"""
    for attempt in range(retries):
        try:
            data = bus.read_i2c_block_data(address, 0x4E, 7)

            xMag = float(data[1] * 256 + data[2])
            if xMag > 32767:
                xMag -= 65536
            xMag *= 0.300 * 0.01

            yMag = float(data[3] * 256 + data[4])
            if yMag > 32767:
                yMag -= 65536
            yMag *= 0.300 * 0.01

            zMag = float(data[5] * 256 + data[6])
            if zMag > 32767:
                zMag -= 65536
            zMag *= 0.484 * 0.01

            return (xMag, yMag, zMag)
        except Exception as e:
            print(f"Retry {attempt + 1}/{retries} failed for reading magnetic field data from sensor at address {address}: {e}")
            if attempt == retries - 1:
                print(f"Failed to read magnetic field data from sensor at address {address} after {retries} retries: {e}")
                return (0.0, 0.0, 0.0)

def read_and_print_data(address, rate, stop_event):
    """Function for reading, printing, and saving sensor data to console and CSV"""
    rate_limiter = 1.0 / rate

    while not stop_event.is_set():
        try:
            start_single_measurement(address)
            xMag, yMag, zMag = read_magnetic_field(address)
            current_time = time.time()

            # Store data in the sensor_data dictionary
            sensor_data[address]['time'].append(current_time)
            sensor_data[address]['x'].append(xMag)
            sensor_data[address]['y'].append(yMag)
            sensor_data[address]['z'].append(zMag)

            # Print the magnetic field values to the console
            print(f"Sensor {sensor_labels[address]} - Time={current_time:.2f}s, X={xMag:.2f}uT, Y={yMag:.2f}uT, Z={zMag:.2f}uT")

            time.sleep(rate_limiter)

        except Exception as e:
            print(f"Error in sensor reading loop for address {address}: {e}")
            break

def write_data_to_csv():
    """Function to write sensor data to a CSV file"""
    with open(csv_filename, mode='w', newline='') as file:
        writer = csv.writer(file)
        
        # Write the header
        headers = ['Time', 'Sensor', 'X', 'Y', 'Z']
        writer.writerow(headers)
        
        # Write the sensor data
        for addr in sensor_addresses:
            for i in range(len(sensor_data[addr]['time'])):
                writer.writerow([sensor_data[addr]['time'][i], sensor_labels[addr],
                                sensor_data[addr]['x'][i], sensor_data[addr]['y'][i],
                                sensor_data[addr]['z'][i]])

def plot_sensor_data():
    """Function to plot sensor data"""
    plt.figure(figsize=(10, 6))

    for addr in sensor_addresses:
        plt.plot(sensor_data[addr]['time'], sensor_data[addr]['x'], label=f'{sensor_labels[addr]} - X')
        plt.plot(sensor_data[addr]['time'], sensor_data[addr]['y'], label=f'{sensor_labels[addr]} - Y')
        plt.plot(sensor_data[addr]['time'], sensor_data[addr]['z'], label=f'{sensor_labels[addr]} - Z')

    plt.xlabel('Time (s)')
    plt.ylabel('Magnetic Field (uT)')
    plt.title('Magnetic Field Readings Over Time')
    plt.legend()
    plt.show()

if __name__ == "__main__":
    # Initialize sensors
    for addr in sensor_addresses:
        init_mlx90393(addr)

    stop_event = threading.Event()

    # Use ThreadPoolExecutor to read and print data from sensors concurrently
    with ThreadPoolExecutor(max_workers=len(sensor_addresses)) as executor:
        for addr in sensor_addresses:
            executor.submit(read_and_print_data, addr, publish_rate, stop_event)  # Best 100-110Hz

        try:
            while True:
                time.sleep(1)  # Keep the main thread alive
        except KeyboardInterrupt:
            stop_event.set()
            print("Measurement complete. Stopping sensor reading threads.")

    # Save data to CSV and plot results
    write_data_to_csv()
    plot_sensor_data()
